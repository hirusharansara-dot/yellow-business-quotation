from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def quotation():
    data = {
        "business_name": "",
        "building": 0,
        "stock": 0,
        "electric_items": 0,
        "glasses": 0,
    }
    selected = {
        "fire": True,
        "rcc": True,
        "burglary": True,
        "electric_items": True,
        "glasses": True,
        "tc": True,
    }

    if request.method == "POST":
        data["business_name"] = request.form.get("business_name", "").strip()
        for key in ("building", "stock", "electric_items", "glasses"):
            try:
                data[key] = max(0, float(request.form.get(key, "0") or 0))
            except ValueError:
                data[key] = 0

        for key in selected:
            selected[key] = request.form.get("cover_" + key) == "on"

    A = data["building"]
    B = data["stock"]
    C = data["electric_items"]
    D = data["glasses"]

    # Calculate the cover premiums, but only include covers selected by the user.
    premiums = {
        "fire": ((A + B) / 100) * 0.3,
        "rcc": ((A + B) / 100) * 0.05,
        "burglary": ((A + B) / 100) * 0.175,
        "electric_items": (C / 100) * 0.5,
        "glasses": (D / 100) * 3,
        "tc": ((A + B) / 100) * 0.0375,
    }
    premiums = {key: value if selected[key] else 0 for key, value in premiums.items()}

    cover_sum = sum(premiums.values())
    admin_fee = (cover_sum / 100) * 3
    policy_fee = 300
    vat = (cover_sum / 100) * 18
    total = cover_sum + admin_fee + policy_fee + vat

    return render_template(
        "index.html",
        data=data,
        selected=selected,
        premiums=premiums,
        cover_sum=cover_sum,
        admin_fee=admin_fee,
        policy_fee=policy_fee,
        vat=vat,
        total=total,
    )

if __name__ == "__main__":
    app.run(debug=True)
