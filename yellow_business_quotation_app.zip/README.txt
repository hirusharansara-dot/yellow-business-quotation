# Yellow Business Insurance Quotation App

## Requirements
- Python 3.9+
- Flask

## Install
Open Command Prompt / Terminal in this folder and run:

```bash
python -m pip install flask
```

## Run
```bash
python app.py
```

Then open the local address shown in the terminal (usually http://127.0.0.1:5000) in your browser.

## Use
1. Enter business name and the four values.
2. Select/unselect covers.
3. Press **Calculate Quotation**.
4. Press **Print / Save as PDF** and choose “Save as PDF” in the print dialog.

## Calculation notes
- Selected cover premiums only are included in the E–J subtotal.
- Admin fee = 3% of E–J subtotal.
- Policy fee = Rs. 300.
- VAT = 18% of E–J subtotal, following the formula supplied.
- Total = E + F + G + H + I + J + K + L + M.

This is a basic local app. It does not save past quotations or provide user login.
